import { useState, useEffect } from 'react'

const frames = [
  {
    emoji: '💕',
    caption: 'Frame 1',
    bg: 'from-mase-100 to-mase-50',
    label: 'The wave',
  },
  {
    emoji: '🫶',
    caption: 'Frame 2',
    bg: 'from-mpho-100 to-mpho-50',
    label: 'Finger heart',
  },
  {
    emoji: '😂',
    caption: 'Frame 3',
    bg: 'from-mase-200 to-mase-100',
    label: 'The goof',
  },
  {
    emoji: '✨',
    caption: 'Frame 4',
    bg: 'from-mpho-200 to-mpho-100',
    label: 'The heart',
  },
]

export default function Photobooth({ theme }) {
  const [activeFrame, setActiveFrame] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFrame((f) => (f + 1) % frames.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const isMase = theme === 'mase'

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-4xl mx-auto">
        {/* Frame counter */}
        <div className="flex items-center justify-center gap-3 mb-6 text-sm text-gray-400 font-mono">
          <span className={isMase ? 'text-mase-500' : 'text-mpho-500'}>● you</span>
          <span className="text-gray-300">+</span>
          <span className={isMase ? 'text-mpho-500' : 'text-mase-500'}>● me</span>
        </div>

        <p className="text-center text-gray-400 text-sm mb-8">
          shot {activeFrame + 1} / {frames.length}
        </p>

        {/* Photo strip */}
        <div className="relative max-w-sm mx-auto">
          {/* Strip border */}
          <div className={`border-8 rounded-3xl overflow-hidden shadow-2xl ${
            isMase ? 'border-mase-100' : 'border-mpho-100'
          }`}>
            {frames.map((frame, i) => (
              <div
                key={i}
                className={`relative h-40 flex items-center justify-center bg-gradient-to-br ${frame.bg} transition-all duration-700 ${
                  i === activeFrame ? 'opacity-100 scale-100' : 'opacity-60 scale-95'
                }`}
              >
                <span className="text-5xl transition-transform duration-500 hover:scale-125 cursor-default">
                  {frame.emoji}
                </span>
                <span className="absolute bottom-2 left-3 text-xs text-gray-400 font-mono">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span className="absolute bottom-2 right-3 text-xs text-gray-400 italic">
                  {frame.label}
                </span>
              </div>
            ))}
          </div>

          {/* Glow effect */}
          <div className={`absolute -inset-4 rounded-[2rem] -z-10 opacity-30 blur-2xl ${
            isMase ? 'bg-mase-300' : 'bg-mpho-300'
          }`} />
        </div>

        {/* Room code display */}
        <div className="text-center mt-8">
          <p className="text-sm text-gray-400 mb-2">masechaba mpho ·</p>
          <p className="text-2xl font-mono font-bold tracking-[0.3em] text-gray-800">
            KX7RM
          </p>
        </div>
      </div>
    </section>
  )
}
