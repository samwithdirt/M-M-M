import { useState, useEffect } from 'react'

const heartFrames = [
  { char: '♥', delay: 0 },
  { char: '♡', delay: 0.5 },
  { char: '♥', delay: 1 },
  { char: '❤', delay: 1.5 },
  { char: '♥', delay: 2 },
]

export default function Hero({ theme }) {
  const [heartIndex, setHeartIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setHeartIndex((i) => (i + 1) % heartFrames.length)
    }, 1200)
    return () => clearInterval(interval)
  }, [])

  const isMase = theme === 'mase'
  const isMpho = theme === 'mpho'
  const isDuo = theme === 'duo'

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20 gradient-hero overflow-hidden">
      {/* Floating hearts background */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <span
            key={i}
            className="absolute text-2xl animate-float opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${4 + Math.random() * 6}s`,
            }}
          >
            {i % 3 === 0 ? '♥' : i % 3 === 1 ? '♡' : '❤'}
          </span>
        ))}
      </div>

      <div className="relative z-10 text-center max-w-2xl mx-auto animate-fade-in">
        {/* Heart animation */}
        <div className="text-5xl md:text-7xl mb-6">
          <span
            className={`inline-block transition-all duration-500 ${
              isMase ? 'text-mase-500' : isMpho ? 'text-mpho-500' : 'text-gradient-duo'
            }`}
          >
            {heartFrames[heartIndex].char}
          </span>
        </div>

        {/* Main headline */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold tracking-tight mb-4">
          <span className={isMase ? 'text-gradient-mase' : isMpho ? 'text-gradient-mpho' : 'text-gradient-mase'}>
            Masechaba
          </span>{' '}
          <span className={isDuo ? 'text-gradient-duo' : isMase ? 'text-mase-400' : isMpho ? 'text-mpho-400' : 'text-gray-400'}>
            {isDuo ? '♡' : '&'}
          </span>{' '}
          <span className={isMpho ? 'text-gradient-mpho' : isMase ? 'text-gradient-mase' : 'text-gradient-mpho'}>
            Mpho
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-gray-600 font-light mb-3 leading-relaxed">
          made for two · <span className="font-medium">11 realtime activities</span>
        </p>

        <h2 className="text-3xl md:text-5xl font-display font-bold text-gray-900 mb-8">
          Fun Dates for{' '}
          <span className="relative">
            Long Distance
            <svg className="absolute -bottom-1 left-0 w-full h-3 -z-10" viewBox="0 0 200 12" preserveAspectRatio="none">
              <path d="M0,6 Q25,0 50,6 T100,6 T150,6 T200,6" fill="none" stroke={isMase ? '#f8a8c4' : isMpho ? '#93b8db' : '#f8a8c4'} strokeWidth="8" strokeLinecap="round" opacity="0.4"/>
            </svg>
          </span>
          <br />Relationships
        </h2>

        {/* Personal story */}
        <p className="text-gray-500 max-w-lg mx-auto mb-8 leading-relaxed">
          This was made for two hearts navigating the distance. A little hub of dates 
          and activities to keep the spark burning bright — no matter how many miles 
          stand between you.
        </p>

        {/* Platform badges */}
        <div className="flex items-center justify-center gap-4 mb-10">
          {['Web', 'Android', 'iOS'].map((platform) => (
            <span
              key={platform}
              className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                isMase
                  ? 'border-mase-200 text-mase-600 bg-mase-50'
                  : isMpho
                  ? 'border-mpho-200 text-mpho-600 bg-mpho-50'
                  : 'border-gray-200 text-gray-600 bg-gray-50'
              }`}
            >
              available on {platform}
            </span>
          ))}
        </div>

        {/* Scroll indicator */}
        <div className="animate-bounce mt-8">
          <svg className="w-6 h-6 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  )
}
