import { useEffect, useState, useRef } from 'react'

const stats = [
  { value: 2847, suffix: '', label: 'active dates', icon: '💫' },
  { value: 12403, suffix: '', label: 'photobooth sessions', icon: '📸' },
  { value: 3916, suffix: '', label: 'photostrips printed', icon: '🖼️' },
]

function AnimatedNumber({ target }) {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const counted = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !counted.current) {
          counted.current = true
          let start = 0
          const duration = 2000
          const increment = Math.ceil(target / (duration / 16))
          const timer = setInterval(() => {
            start += increment
            if (start >= target) {
              setCount(target)
              clearInterval(timer)
            } else {
              setCount(start)
            }
          }, 16)
        }
      },
      { threshold: 0.5 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [target])

  return <span ref={ref}>{count.toLocaleString()}</span>
}

export default function Stats() {
  return (
    <section className="py-16 px-4 bg-gradient-to-r from-mase-50 via-white to-mpho-50">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, i) => (
            <div key={i} className="text-center group">
              <span className="text-3xl mb-3 block group-hover:scale-125 transition-transform duration-300">
                {stat.icon}
              </span>
              <div className="text-4xl md:text-5xl font-display font-bold text-gray-900 mb-1">
                <AnimatedNumber target={stat.value} />
                {stat.suffix}
              </div>
              <p className="text-gray-400 text-sm uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
