const activities = [
  { name: 'Riddle Night', emoji: '🧩', desc: 'Solve puzzles together in real time', color: 'from-amber-400 to-orange-400' },
  { name: 'IQ Duel', emoji: '🧠', desc: 'Who\'s sharper tonight?', color: 'from-purple-400 to-pink-400' },
  { name: 'Couples Quiz', emoji: '💞', desc: 'How well do you know each other?', color: 'from-mase-400 to-mase-500' },
  { name: 'Photobooth', emoji: '📸', desc: 'Strike a pose — together, apart', color: 'from-mpho-400 to-mpho-500' },
  { name: 'Couples Debate', emoji: '🎤', desc: 'Settle it like grown-ups (or not)', color: 'from-green-400 to-teal-400' },
  { name: 'Draw Together', emoji: '🎨', desc: 'One canvas, two artists', color: 'from-sky-400 to-blue-400' },
  { name: 'Couples Court', emoji: '⚖️', desc: 'The judge rules. No appeals.', color: 'from-red-400 to-rose-400' },
  { name: 'Snap Hunt', emoji: '🔍', desc: 'Scavenger hunt across your rooms', color: 'from-yellow-400 to-amber-400' },
  { name: 'Fashion Show', emoji: '👗', desc: 'Rate each other\'s fits', color: 'from-pink-400 to-rose-400' },
  { name: 'Arcade', emoji: '🕹️', desc: 'Face-avatar retro games', color: 'from-indigo-400 to-violet-400' },
  { name: 'The Lab', emoji: '🔬', desc: 'Study-date game for curious couples', color: 'from-cyan-400 to-blue-400' },
]

export default function Activities() {
  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm text-gray-400 uppercase tracking-[0.2em] mb-3">
            Activities to do together, apart
          </p>
          <h2 className="text-3xl md:text-5xl font-display font-bold text-gray-900 max-w-2xl mx-auto leading-tight">
            One hub of games & dates for long distance couples.
          </h2>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto">
            Distance makes "doing something together" hard. Here are eleven realtime 
            games and dates you play in one shared room, at the exact same second.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {activities.map((activity) => (
            <button
              key={activity.name}
              className="group relative p-5 rounded-2xl border border-gray-100 bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${activity.color} flex items-center justify-center text-lg mb-3 group-hover:scale-110 transition-transform`}>
                {activity.emoji}
              </div>
              <h3 className="font-semibold text-gray-900 text-sm mb-1">{activity.name}</h3>
              <p className="text-gray-400 text-xs leading-relaxed">{activity.desc}</p>
            </button>
          ))}
        </div>

        <div className="text-center mt-10">
          <a href="#" className="inline-flex items-center gap-2 text-mase-500 hover:text-mase-600 font-medium transition-colors">
            Browse all activities
            <span>→</span>
          </a>
        </div>
      </div>
    </section>
  )
}
