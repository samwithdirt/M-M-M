import { useState } from 'react'

const question = {
  text: "What's Masechaba's go-to karaoke song?",
  options: ['Bohemian Rhapsody', 'Something by Tyla', 'Rap god, allegedly'],
}

export default function Quiz() {
  const [mase, setMase] = useState(null)
  const [mpho, setMpho] = useState(null)
  const [revealed, setRevealed] = useState(false)
  const correct = 1
  const matched = revealed && mase === mpho && mase === correct

  const reset = () => { setMase(null); setMpho(null); setRevealed(false) }

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-sm text-gray-400 uppercase tracking-[0.2em] mb-3">See it in action</p>
          <h2 className="text-3xl md:text-5xl font-display font-bold text-gray-900">Watch a round of our most-played game.</h2>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto">
            One question, two screens. Lock in privately, then answers flip at the same second. Match, and confetti flies.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {[{ name: 'Masechaba', val: mase, set: setMase, border: 'border-mase-200', accent: 'mase', role: 'answers honestly' },
            { name: 'Mpho', val: mpho, set: setMpho, border: 'border-mpho-200', accent: 'mpho', role: 'guesses her answer' }
          ].map((p) => (
            <div key={p.name} className={`bg-white rounded-3xl border-2 ${p.border} shadow-xl p-6`}>
              <div className="flex items-center gap-2 mb-4">
                <div className={`w-8 h-8 rounded-full bg-gradient-to-br from-${p.accent}-300 to-${p.accent}-500 flex items-center justify-center text-white text-xs font-bold`}>
                  {p.name[0]}
                </div>
                <span className={`text-sm font-medium text-${p.accent}-600`}>{p.name}</span>
                <span className="text-xs text-gray-400 ml-auto">{p.role}</span>
              </div>
              <p className="text-sm text-gray-700 mb-4">{question.text} 🎤</p>
              <div className="space-y-2">
                {question.options.map((opt, i) => (
                  <button key={i} onClick={() => !revealed && p.set(i)} disabled={revealed}
                    className={`w-full text-left px-4 py-3 rounded-xl border-2 text-sm transition-all ${
                      p.val === i ? `border-${p.accent}-400 bg-${p.accent}-50 text-${p.accent}-700`
                      : 'border-gray-100 hover:border-gray-200 text-gray-600'
                    } ${revealed && i === correct ? 'border-green-400 bg-green-50 text-green-700' : ''}
                    ${revealed && p.val === i && i !== correct ? 'border-red-300 bg-red-50 text-red-600' : ''}`}>
                    {opt}
                  </button>
                ))}
              </div>
              {p.val !== null && !revealed && <p className={`text-center mt-4 text-xs text-${p.accent}-400 font-medium`}>locked in ✓</p>}
            </div>
          ))}
        </div>
        {revealed && (
          <div className="text-center mt-8 animate-fade-in">
            <span className={`inline-flex items-center gap-2 px-6 py-3 rounded-full border ${matched ? 'bg-green-50 border-green-200 text-green-700' : 'bg-gray-50 border-gray-200 text-gray-500'}`}>
              {matched ? '💞 ✓ Matched!' : 'Not quite — try again!'}
            </span>
          </div>
        )}
        <div className="text-center mt-8">
          {mase !== null && mpho !== null && !revealed ? (
            <button onClick={() => setRevealed(true)} className="px-8 py-3 bg-mase-500 text-white rounded-full font-medium hover:bg-mase-600 transition-colors shadow-lg">Reveal answers</button>
          ) : revealed ? (
            <button onClick={reset} className="px-8 py-3 border-2 border-gray-200 text-gray-600 rounded-full font-medium hover:border-gray-300">Play again</button>
          ) : (
            <p className="text-sm text-gray-400">Both pick an answer, then reveal together</p>
          )}
        </div>
      </div>
    </section>
  )
}
