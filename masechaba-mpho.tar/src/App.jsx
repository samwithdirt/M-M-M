import { useState } from 'react'
import Hero from './components/Hero'
import Photobooth from './components/Photobooth'
import RoomCode from './components/RoomCode'
import Stats from './components/Stats'
import Activities from './components/Activities'
import Quiz from './components/Quiz'
import Merch from './components/Merch'
import Faq from './components/Faq'
import Footer from './components/Footer'

export default function App() {
  const [activeTheme, setActiveTheme] = useState('duo')

  return (
    <div className="min-h-screen overflow-x-hidden">
      <ThemeToggle active={activeTheme} onChange={setActiveTheme} />
      <Hero theme={activeTheme} />
      <Photobooth theme={activeTheme} />
      <RoomCode />
      <Stats />
      <Activities />
      <Quiz />
      <Merch />
      <Faq />
      <Footer />
    </div>
  )
}

function ThemeToggle({ active, onChange }) {
  const themes = [
    { id: 'duo', label: 'Masechaba ♡ Mpho', className: 'bg-gradient-to-r from-mase-500 to-mpho-500' },
    { id: 'mase', label: 'Masechaba', className: 'bg-mase-500' },
    { id: 'mpho', label: 'Mpho', className: 'bg-mpho-500' },
  ]
  return (
    <div className="fixed top-4 right-4 z-50 flex gap-2 bg-white/80 backdrop-blur-sm rounded-full p-1 shadow-lg border border-gray-100">
      {themes.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
            active === t.id
              ? `${t.className} text-white shadow-md`
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {t.label}
        </button>
      ))}
    </div>
  )
}
