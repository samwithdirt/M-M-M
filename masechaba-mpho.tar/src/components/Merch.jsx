export default function Merch() {
  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-sm text-gray-400 uppercase tracking-[0.2em] mb-3">Keepsakes · ships worldwide</p>
        <h2 className="text-3xl md:text-5xl font-display font-bold text-gray-900 mb-6">
          Preserve your LDR memories by printing your photobooth strips.
        </h2>
        <p className="text-gray-500 max-w-lg mx-auto mb-12 leading-relaxed">
          Turn today's session into something you can actually hold. We print your strip 
          as a die-cut fridge magnet and ship it worldwide — send one to each of you.
        </p>
        <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto text-left">
          {[
            { icon: '🧲', title: 'Die-cut vinyl magnets', desc: 'From your real HD strip' },
            { icon: '📮', title: 'Ship to both addresses', desc: 'One order, two destinations' },
            { icon: '💫', title: '20% off 3+ strips', desc: 'Stock up on memories' },
          ].map((item) => (
            <div key={item.title} className="p-6 rounded-2xl bg-gradient-to-b from-gray-50 to-white border border-gray-100">
              <span className="text-2xl mb-3 block">{item.icon}</span>
              <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
        <button className="mt-10 px-8 py-3 bg-mase-500 text-white rounded-full font-medium hover:bg-mase-600 transition-colors shadow-lg shadow-mase-200">
          Order a strip →
        </button>
      </div>
    </section>
  )
}
