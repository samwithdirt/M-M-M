import { useState } from 'react'

const faqs = [
  {
    q: 'What games can we play together?',
    a: 'Eleven realtime activities are live: Riddle Night, IQ Duel, the How Well Do You Know Me quiz, the online photobooth, Couples Debate, Draw Together, Couples Court, Snap Hunt, Fashion Show, a face-avatar Arcade, and The Lab study-date game. Everything happens in one shared room at the same second.',
  },
  {
    q: 'Is this free to play?',
    a: 'Yes. Open a room, share the 5-letter code, and play together for free — the photobooth is always free and every game has a free tier.',
  },
  {
    q: 'How does a realtime online date work?',
    a: 'One person opens a room and sends the code; the other joins from anywhere. You see each other\'s live cursors, lock in answers privately, and reveal at the exact same second.',
  },
  {
    q: 'Do we need to install an app?',
    a: 'No. It runs right in the browser on phone or laptop — nothing to download.',
  },
  {
    q: 'Is the photobooth like Life4Cuts?',
    a: 'Yes — built in the Korean Life4Cuts (인생네컷) style, but online and made for two people in different places. You get the same clean photo strip you\'d print from a booth.',
  },
]

export default function Faq() {
  const [open, setOpen] = useState(null)

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 text-center mb-3">Good to know</h2>
        <p className="text-gray-400 text-center mb-12">Questions long distance couples ask.</p>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 hover:bg-gray-50 transition-colors"
              >
                <span className="font-medium text-gray-900">{faq.q}</span>
                <span className={`text-gray-400 transition-transform duration-300 ${open === i ? 'rotate-45' : ''}`}>
                  +
                </span>
              </button>
              {open === i && (
                <div className="px-6 pb-5 text-gray-500 leading-relaxed animate-fade-in">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
