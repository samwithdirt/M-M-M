export default function Footer() {
  return (
    <footer className="py-16 px-4 bg-gray-900 text-gray-400">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-4xl mb-4">♡</p>
        <p className="text-xl font-display font-semibold text-white mb-2">
          Masechaba <span className="text-mase-400">♡</span> Mpho
        </p>
        <p className="text-sm mb-8">made for two · 11 realtime activities</p>
        <div className="flex items-center justify-center gap-6 text-sm">
          <a href="#" className="hover:text-white transition-colors">Activities</a>
          <a href="#" className="hover:text-white transition-colors">Photobooth</a>
          <a href="#" className="hover:text-white transition-colors">Shop</a>
          <a href="#" className="hover:text-white transition-colors">FAQ</a>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800">
          <p className="text-xs">
            Available on Web · Android · iOS &nbsp;|&nbsp; Built with ♡ for long distance couples
          </p>
        </div>
      </div>
    </footer>
  )
}
