import { useState } from 'react'

const CODE_LENGTH = 5

export default function RoomCode() {
  const [code, setCode] = useState(['', '', '', '', ''])
  const [focused, setFocused] = useState(0)
  const [hasCode, setHasCode] = useState(false)

  const handleInput = (index, value) => {
    if (value.length > 1) return
    const newCode = [...code]
    newCode[index] = value.toUpperCase()
    setCode(newCode)
    if (value && index < CODE_LENGTH - 1) {
      setFocused(index + 1)
    }
  }

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      setFocused(index - 1)
    }
  }

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-lg mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
          Pick tonight's activity.
        </h2>
        <p className="text-gray-500 mb-10">
          Open a room and send the code. They'll be there in a tap.
        </p>

        {/* Code display */}
        {!hasCode ? (
          <div className="flex items-center justify-center gap-3 mb-8">
            {code.map((char, i) => (
              <input
                key={i}
                type="text"
                maxLength={1}
                value={char}
                onChange={(e) => handleInput(i, e.target.value)}
                onKeyDown={(e) => handleKeyDown(i, e)}
                onFocus={() => setFocused(i)}
                ref={(el) => { if (i === focused) el?.focus() }}
                className={`w-14 h-16 text-2xl font-mono font-bold text-center rounded-xl border-2 transition-all outline-none ${
                  char
                    ? 'border-mase-400 bg-mase-50 text-mase-600'
                    : 'border-gray-200 bg-white text-gray-900 hover:border-gray-300'
                } focus:border-mase-500 focus:ring-4 focus:ring-mase-100`}
              />
            ))}
          </div>
        ) : (
          <div className="mb-8 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-mase-50 rounded-2xl border border-mase-200">
              <span className="text-lg font-mono font-bold tracking-[0.3em] text-mase-600">
                {code.join('')}
              </span>
              <span className="text-mase-400">✓</span>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => setHasCode(true)}
            className="px-8 py-3 bg-mase-500 text-white rounded-full font-medium hover:bg-mase-600 transition-colors shadow-lg shadow-mase-200"
          >
            Create a room
          </button>
          <button
            onClick={() => setHasCode(true)}
            className="text-gray-500 hover:text-gray-700 text-sm font-medium transition-colors"
          >
            have a code?{' '}
            <span className="font-mono tracking-[0.2em] text-gray-700">KX7RM</span>
          </button>
        </div>
      </div>
    </section>
  )
}
