export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        mase: { 50:'#fef7f9',100:'#fde8ef',200:'#fbd0e0',300:'#f8a8c4',400:'#f2719e',500:'#e8457a',600:'#d42a5f',700:'#b31b44',800:'#941a3a',900:'#7c1a35',950:'#4a0a1b' },
        masegold: { 50:'#fefce8',100:'#fef9c3',200:'#fef08a',300:'#fde047',400:'#facc15',500:'#eab308' },
        mpho: { 50:'#f0f5fa',100:'#dce7f3',200:'#bfd4e9',300:'#93b8db',400:'#6197c9',500:'#3e7ab4',600:'#2e6198',700:'#274e7b',800:'#244367',900:'#1e3552',950:'#0f1a2e' },
        mphoamber: { 50:'#fffbeb',100:'#fef3c7',200:'#fde68a',300:'#fcd34d',400:'#fbbf24',500:'#f59e0b' },
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4,0,0.6,1) infinite',
        'fade-in': 'fadeIn 0.6s ease-out',
      },
      keyframes: {
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-20px)' } },
        fadeIn: { '0%': { opacity: '0', transform: 'translateY(10px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
      },
    },
  },
  plugins: [],
}
